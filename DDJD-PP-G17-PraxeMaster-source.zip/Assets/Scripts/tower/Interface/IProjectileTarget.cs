﻿using UnityEngine;

public interface IProjectileTarget
{
    void Init(Transform Target);
}