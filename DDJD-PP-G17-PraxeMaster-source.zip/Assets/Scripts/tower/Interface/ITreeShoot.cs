﻿using UnityEngine;
    public interface ITreeShoot
    {
        void Shoot (Transform target);
    }
