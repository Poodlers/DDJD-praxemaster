using System.Collections;

public interface IFireRater
{
    IEnumerator Wait();
}